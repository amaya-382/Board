Board
=====

An illustration of Simple Http Framework

## Usage
```
java -jar board-1.0.0.jar
```

## Acknowledgement
* [json4s](https://github.com/json4s/json4s)
* [knockoff](https://github.com/tristanjuricek/knockoff/)
